/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycart;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Mons
 */
public class MakePayment extends javax.swing.JFrame {

    
                        
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel[] jItemName = new JLabel[30];
    private javax.swing.JLabel[] jItemPrice = new JLabel[30];
    private javax.swing.JLabel[] jDelete = new JLabel[30];
    private javax.swing.JLabel jLTotal;
    private javax.swing.JLabel jTotalPrice;
    ResultSet rs,rs1;
    DBConnect dbconnect;
    int item_count,total_price=0;
    int [] price = new int[30];
    int [] s_item_id = new int[30];
    String [] item_name = new String[30];
    
    private void centerFrame() 
    {

            System.out.println("Hello");
            Dimension windowSize = getSize();
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Point centerPoint = ge.getCenterPoint();

            int dx = centerPoint.x - windowSize.width / 2;
            int dy = centerPoint.y - windowSize.height / 2;    
            setLocation(dx-250, dy-250);
    }
    
    
    public MakePayment() 
    {
        dbconnect = new DBConnect();
        rs = dbconnect.getData("select * from cart_details where customer_id = '"+MyCart.user_cookie+"' && payment_status=0");
        try 
        {
            int i=0;
            while(rs.next())
            {
                s_item_id[i] = rs.getInt(3);
                price[i] = rs.getInt("product_price");
                i++;
            }
            item_count = i;
        } catch (SQLException ex) {
            Logger.getLogger(Dash.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        initComponents();
        centerFrame();
    }

public void getLabels(int count)
    {
        int base = 138;
        
        for(int i=0;i<count;i++)
        {
            String name = null;
            jItemName[i] = new JLabel();
            jItemName[i].setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
            jItemName[i].setForeground(new java.awt.Color(102, 102, 102));
            {
                ResultSet rr;
                rr = dbconnect.getData("select name from products where id ='"+s_item_id[i]+"'");
                try {
                    while(rr.next())
                    {
                            name = rr.getString(1);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(MakePayment.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            jItemName[i].setText(name);
            getContentPane().add(jItemName[i]);
            jItemName[i].setBounds(10, base, 210, 35);
            base = base+40;
        }
        base = 138;
        for(int i=0;i<count;i++)
        {
            jItemPrice[i] = new JLabel();
            jItemPrice[i].setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
            jItemPrice[i].setForeground(new java.awt.Color(102, 102, 102));
            jItemPrice[i].setText(""+price[i]);
            getContentPane().add(jItemPrice[i]);
            jItemPrice[i].setBounds(380, base, 130, 35);
            base = base+40;
            total_price = total_price+price[i];
        }
        base = 138;
        for(int i=0;i<count;i++)
        {
            jDelete[i] = new JLabel();
            jDelete[i].setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
            jDelete[i].setForeground(new java.awt.Color(204, 0, 0));
            jDelete[i].setText("Delete");
            getContentPane().add(jDelete[i]);
            jDelete[i].setBounds(568, base, 62, 13);
            jDelete[i].setName(Integer.toString(s_item_id[i]));
            jDelete[i].addMouseListener(new java.awt.event.MouseAdapter() 
            {
                public void mouseClicked(java.awt.event.MouseEvent evt) 
                {
                    labelMouseClicked(evt);
                }
            
            });
            base = base+40;
        }
    }
                           
    
    
    private void initComponents() {
        
        getContentPane().setBackground(Color.white);
        jButton1 = new javax.swing.JButton();
        jLTotal = new javax.swing.JLabel();
        jTotalPrice = new javax.swing.JLabel();
        
        getLabels(item_count);
        

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 102, 0));
        jButton1.setText("Make Payment >>");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 403, 620, 55);

        
        jLTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLTotal.setForeground(new java.awt.Color(0, 102, 0));
        jLTotal.setText("Total = ");
        getContentPane().add(jLTotal);
        jLTotal.setBounds(10, 62, 68, 35);

        jTotalPrice.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTotalPrice.setForeground(new java.awt.Color(0, 102, 0));
        jTotalPrice.setText(""+total_price);
        getContentPane().add(jTotalPrice);
        jTotalPrice.setBounds(96, 62, 194, 35);

        pack();
    }// </editor-fold>                        

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) 
    {                                        
        SelectPaymentMethod spm = new SelectPaymentMethod(total_price);
        spm.setSize(651, 500);
        this.setVisible(false);
        spm.setVisible(true);
    }                                      
    
    private void labelMouseClicked(MouseEvent evt) 
    {                                        
        int confirm;
        confirm = JOptionPane.showConfirmDialog(rootPane,"R u Sure u want to delete...???", "Confirm", WIDTH, WIDTH,null);
        if(confirm == JOptionPane.OK_OPTION)
        {
            dbconnect.insertData("delete from cart_details where product_id = '"+Integer.parseInt(evt.getComponent().getName())+"'");
            JOptionPane.showMessageDialog(rootPane,"Item deleted from cart successfully...");
        }
    
    }  
    

                     
}
