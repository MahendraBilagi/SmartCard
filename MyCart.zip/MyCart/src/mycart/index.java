
package mycart;


import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;


public class index extends javax.swing.JFrame {

    private JLabel[] labels = new JLabel[100];
    String[] path = new String[100];
    String[] item_name = new String[100];
    ImageIcon[] icon = new ImageIcon[100];
    int[] s_item_id = new int[100];
    int[] price = new int[100];
    JLabel show_name,gomycart;
    private JButton  b_login; 
    DBConnect dbconnect;
    ResultSet rs,rs1;
    public static int global_select;
    int item_count,flag=0;
    
    private JLabel[] createLabels(int count)
    {
        int ypos,xpos=35,row;
        
        
        for(int i=0;i<count;i++)
        {
            row = i/5;
            
            switch(row)
            {
                case 0:
                    ypos = 154;
                    break;
                case 1:
                    ypos = 272;
                    break;
                case 2:
                    ypos = 390;
                    break;
                case 3:
                    ypos = 508;
                    break;
                case 4:
                    ypos = 626;
                    break;
                default :
                    ypos = 154;
                    break;
            }
            flag++;
            
                //labels[i] = new JLabel(Integer.toString(i));
                
                labels[i] = new JLabel();
                labels[i].setName(Integer.toString(s_item_id[i]));
            labels[i].setCursor(new Cursor(Cursor.HAND_CURSOR));
            labels[i].addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                labelMouseEntered(evt);
            }
             public void mouseExited(java.awt.event.MouseEvent evt) {
                labelMouseExited(evt);
            }
             
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelMouseClicked(evt);
            }
            
        });
            getContentPane().add(labels[i]);
            labels[i].setBounds(xpos, ypos, 100, 100);
            if(flag<=4)
                xpos = xpos+110;
            else
            {
                xpos = 35;
                flag=0;
            }
        }
        return labels;
    }
    
    public void getImage(int count)
    {
            for(int i=0;i<count;i++)
            {
                icon[i] = new ImageIcon(new ImageIcon(path[i]).getImage().getScaledInstance(80, 80, Image.SCALE_DEFAULT));
                labels[i].setIcon((Icon) icon[i]);
            }
    }
    
    private void centerFrame() 
    {

            System.out.println("Hello");
            Dimension windowSize = getSize();
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Point centerPoint = ge.getCenterPoint();

            int dx = centerPoint.x - windowSize.width / 2;
            int dy = centerPoint.y - windowSize.height / 2;    
            setLocation(dx-250, dy-250);
    }
    
    
    private void initComponents() {

        getContentPane().setBackground(Color.white);
        createLabels(item_count);
        getImage(item_count);
        
        gomycart = new JLabel();
        gomycart.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gomycart.setFont(new java.awt.Font("Tahoma", 2, 14)); // NOI18N
        gomycart.setForeground(new java.awt.Color(0, 204, 51));
        gomycart.setText("Go to MyCart");
        gomycart.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gomycartMouseClicked(evt);
            }
        });
        getContentPane().add(gomycart);
        gomycart.setBounds(520, 10, 120, 20);
        
        
        show_name = new JLabel();
        show_name.setForeground(new java.awt.Color(51, 102, 0));
        show_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(show_name);
        show_name.setBounds(10, 100, 590, 17);
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        pack();
    }  
    
    
    public index() 
    {
        dbconnect = new DBConnect();
        rs = dbconnect.getData("select count(*) from products where status=1");
        try 
        {
            while(rs.next())
            {
                item_count = Integer.parseInt(rs.getString(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Dash.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        rs1 = dbconnect.getData("select * from products where status=1");
        try 
        {
            int i=0;
            while(rs1.next())
            {
                path[i] = "C:\\xampp\\htdocs\\mycart\\"+rs1.getString("image");
                s_item_id[i] = rs1.getInt(1);
                price[s_item_id[i]] = rs1.getInt("price");
                item_name[s_item_id[i]] = rs1.getString("name");
                i++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Dash.class.getName()).log(Level.SEVERE, null, ex);
        }
        initComponents();
               centerFrame();
    }

     public void labelMouseEntered(MouseEvent evt)
                {
                    //System.out.println(evt.getComponent().getName());
                    show_name.setText(item_name[Integer.parseInt(evt.getComponent().getName())]+"-> "+price[Integer.parseInt(evt.getComponent().getName())]);
                } 
      public void labelMouseExited(MouseEvent evt)
                {
                    show_name.setText("");
                }
      public void labelMouseClicked(MouseEvent evt)
                {
                    ItemDetails details = new ItemDetails(Integer.parseInt(evt.getComponent().getName()));
                    details.setSize(650, 500);
                    details.setVisible(true);
                    details.setResizable(false);
                    //this.setVisible(false);
                }
      public void gomycartMouseClicked(MouseEvent evt)
      {
          MakePayment mm = new MakePayment();
          mm.setVisible(true);
          this.setVisible(false);
          mm.setResizable(false);
          mm.setSize(650,500);
      }
                          

                 
}
