
package mycart;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class SelectPaymentMethod extends javax.swing.JFrame {

    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jMaster;
    private javax.swing.JLabel jPayPal;
    private javax.swing.JLabel jPayU;
    private javax.swing.JLabel jVisa;
    
    public int passwd,total_price;
    
    public SelectPaymentMethod(int total) 
    {
        this.total_price = total;
        initComponents();
        centerFrame();
    }
    
    private void centerFrame() 
    {

            System.out.println("Hello");
            Dimension windowSize = getSize();
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Point centerPoint = ge.getCenterPoint();

            int dx = centerPoint.x - windowSize.width / 2;
            int dy = centerPoint.y - windowSize.height / 2;    
            setLocation(dx-250, dy-250);
    }

    
    @SuppressWarnings("unchecked")                        
    private void initComponents() 
    {

        jButton1 = new javax.swing.JButton();
        jVisa = new javax.swing.JLabel();
        jPayPal = new javax.swing.JLabel();
        jMaster = new javax.swing.JLabel();
        jPayU = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("<< Close >>");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 403, 620, 55);

        jVisa.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jVisa.setForeground(new java.awt.Color(102, 102, 102));
        jVisa.setText("Visa , 12% off on total Bill");
        jVisa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jVisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jVisaMouseClicked(evt);
            }
        });
        getContentPane().add(jVisa);
        jVisa.setBounds(10, 290, 430, 35);

        jPayPal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jPayPal.setForeground(new java.awt.Color(102, 102, 102));
        jPayPal.setText("PayPal , 25% off on total Bill");
        jPayPal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPayPal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPayPalMouseClicked(evt);
            }
        });
        getContentPane().add(jPayPal);
        jPayPal.setBounds(10, 138, 430, 35);

        jMaster.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMaster.setForeground(new java.awt.Color(102, 102, 102));
        jMaster.setText("MasterCard , 18% off on total Bill");
        jMaster.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMaster.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMasterMouseClicked(evt);
            }
        });
        getContentPane().add(jMaster);
        jMaster.setBounds(10, 190, 430, 35);

        jPayU.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jPayU.setForeground(new java.awt.Color(102, 102, 102));
        jPayU.setText("PayUMoney , 30% off on total Bill");
        //jPayU.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPayU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPayUMouseClicked(evt);
            }
        });
        getContentPane().add(jPayU);
        jPayU.setBounds(10, 240, 430, 35);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 153));
        jLabel1.setText("Select Payment Option");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(210, 20, 280, 50);

        pack();
    }// </editor-fold>                        

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) 
    {                                         
        
    }                                        

    private void jPayPalMouseClicked(java.awt.event.MouseEvent evt) 
    {                                     
        int passwd1=0,passwd2=0,passwd3=0, balence=0;
        String bankname ="bank1";
        int qry;
        ResultSet rs,rs1;
        
       qry =Integer.parseInt(JOptionPane.showInputDialog(rootPane,"Enter 3 digit password of your bank", "enter password", 1));
          
        DBConnect1 dbconnect = new DBConnect1();
        rs = dbconnect.getData("select * from master_password");
        try {
            while(rs.next())
            {
                passwd1 = rs.getInt(3);
                passwd2 = rs.getInt(4);
                passwd3 = rs.getInt(5);
            }
            if(qry == passwd1)
            {
                bankname = "bank1";
            }
            if(qry == passwd2)
            {
                bankname = "bank2";
            }
            if(qry == passwd3)
            {
                bankname = "bank3";
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(SelectPaymentMethod.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(bankname);
            //rs1 = dbconnect.getData("select Balence from"+bankname);        
        rs1 = dbconnect.getData("select Balence from "+bankname+"");        
        try {
                while(rs1.next())
                {
                    balence = rs1.getInt(1);
                }
                total_price = (total_price - ((total_price/100)*25));
                balence = balence - total_price;
            System.out.println(balence);
            dbconnect.insertData("update "+bankname+" set Balence = "+balence+" where id = "+MyCart.user_cookie+"");
            //insertData("update "+bankname+" set Balence = "+balence+" where id = "+MyCart.user_cookie+"");
            //insertData("update bank2 set Balence = 1000 where id = 2");
            
            JOptionPane.showConfirmDialog(rootPane,"Rs "+total_price+" is deducted from your "+bankname+" account...","Congradulations",0);
            
            } 
        catch (SQLException ex) 
        {
            Logger.getLogger(SelectPaymentMethod.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        
        
    }                                    

    private void jMasterMouseClicked(java.awt.event.MouseEvent evt) 
    {                                     
        int passwd1=0,passwd2=0,passwd3=0, balence=0;
        String bankname ="bank1";
        int qry;
        ResultSet rs,rs1;
        
       qry =Integer.parseInt(JOptionPane.showInputDialog(rootPane,"Enter 3 digit password of your bank", "enter password", 1));
          
        DBConnect1 dbconnect = new DBConnect1();
        rs = dbconnect.getData("select * from master_password");
        try {
            while(rs.next())
            {
                passwd1 = rs.getInt(3);
                passwd2 = rs.getInt(4);
                passwd3 = rs.getInt(5);
            }
            if(qry == passwd1)
            {
                bankname = "bank1";
            }
            if(qry == passwd2)
            {
                bankname = "bank2";
            }
            if(qry == passwd3)
            {
                bankname = "bank3";
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(SelectPaymentMethod.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println(bankname);
            //rs1 = dbconnect.getData("select Balence from"+bankname);        
        rs1 = dbconnect.getData("select Balence from "+bankname+"");        
        try {
                while(rs1.next())
                {
                    balence = rs1.getInt(1);
                }
                total_price = (total_price - ((total_price/100)*18));
                balence = balence - total_price;
            System.out.println(balence);
            dbconnect.insertData("update "+bankname+" set Balence = "+balence+" where id = "+MyCart.user_cookie+"");
            //insertData("update "+bankname+" set Balence = "+balence+" where id = "+MyCart.user_cookie+"");
            //insertData("update bank2 set Balence = 1000 where id = 2");
            JOptionPane.showConfirmDialog(rootPane,"Rs "+total_price+" is deducted from your "+bankname+" account...","Congradulations",0);
            } 
        catch (SQLException ex) 
        {
            Logger.getLogger(SelectPaymentMethod.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        
    }                                    

    private void jPayUMouseClicked(java.awt.event.MouseEvent evt) 
    {                                   
        
    }                                  

    private void jVisaMouseClicked(java.awt.event.MouseEvent evt) 
    {                                   
       int passwd1=0,passwd2=0,passwd3=0, balence=0;
        String bankname ="bank1";
        int qry;
        ResultSet rs,rs1;
        
       qry =Integer.parseInt(JOptionPane.showInputDialog(rootPane,"Enter 3 digit password of your bank", "enter password", 1));
          
        DBConnect1 dbconnect = new DBConnect1();
        rs = dbconnect.getData("select * from master_password");
        try {
            while(rs.next())
            {
                passwd1 = rs.getInt(3);
                passwd2 = rs.getInt(4);
                passwd3 = rs.getInt(5);
            }
            if(qry == passwd1)
            {
                bankname = "bank1";
            }
            if(qry == passwd2)
            {
                bankname = "bank2";
            }
            if(qry == passwd3)
            {
                bankname = "bank3";
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(SelectPaymentMethod.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println(bankname);
            //rs1 = dbconnect.getData("select Balence from"+bankname);        
        rs1 = dbconnect.getData("select Balence from "+bankname+"");        
        try {
                while(rs1.next())
                {
                    balence = rs1.getInt(1);
                }
                total_price = (total_price - ((total_price/100)*12));
                balence = balence - total_price;
            System.out.println(balence);
            dbconnect.insertData("update "+bankname+" set Balence = "+balence+" where id = "+MyCart.user_cookie+"");
            //insertData("update "+bankname+" set Balence = "+balence+" where id = "+MyCart.user_cookie+"");
            //insertData("update bank2 set Balence = 1000 where id = 2");
            JOptionPane.showMessageDialog(rootPane,"Rs "+total_price+" is deducted from your "+bankname+" account...","Congradulations",0);
            } 
        catch (SQLException ex) 
        {
            Logger.getLogger(SelectPaymentMethod.class.getName()).log(Level.SEVERE, null, ex);
        }
            
         
    }                                  

   

}
