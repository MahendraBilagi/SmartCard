
package mycart;


public class MyCart {
    public static int user_cookie;
    
    public static void main(String[] args) 
    {
            Login ll = new Login();
            ll.setSize(650, 500);
            ll.setVisible(true);
            ll.setResizable(false);
    }
    
}
