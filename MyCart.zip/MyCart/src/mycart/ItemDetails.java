
package mycart;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Point;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class ItemDetails extends javax.swing.JFrame {

    ImageIcon icon;
    DBConnect dbconnect = new DBConnect();
    ResultSet rs;
    int item_id,price;
    public void decorate(int id)
    {
        dbconnect = new DBConnect();
        rs = dbconnect.getData("select * from products where id ='"+id+"'");
        try 
        {
            while(rs.next())
            {
                String path,name,description;
                name = rs.getString(2);
                path = "C:\\xampp\\htdocs\\mycart\\"+rs.getString(3);
                description = rs.getString(4);
                price = rs.getInt(5);
                
                icon = new ImageIcon(new ImageIcon(path).getImage().getScaledInstance(200, 222, Image.SCALE_DEFAULT));
                photo.setIcon(icon);
                
                LName.setText(name);
                LDesc.setText(description);
                LPrice.setText(""+price);
                
                
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Dash.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    private void centerFrame() 
    {

            System.out.println("Hello");
            Dimension windowSize = getSize();
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Point centerPoint = ge.getCenterPoint();

            int dx = centerPoint.x - windowSize.width / 2;
            int dy = centerPoint.y - windowSize.height / 2;    
            setLocation(dx-250, dy-250);
    }
    
    public ItemDetails(int item_id) 
    {
        this.item_id = item_id;
        getContentPane().setBackground(Color.white);
        initComponents();
        decorate(item_id);
        centerFrame();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        photo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        LName = new javax.swing.JLabel();
        LPrice = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        LDesc = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Item Details");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(247, 31, 200, 22);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(10, 79, 630, 10);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 102, 0));
        jButton1.setText("Add To Cart >>");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 403, 620, 55);
        getContentPane().add(photo);
        photo.setBounds(30, 107, 200, 222);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("Name :");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(275, 125, 41, 15);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Description :");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(240, 270, 77, 15);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Rs :");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(290, 190, 23, 15);

        LName.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        LName.setForeground(new java.awt.Color(51, 51, 51));
        LName.setText("jLabel2");
        getContentPane().add(LName);
        LName.setBounds(370, 114, 240, 30);

        LPrice.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        LPrice.setForeground(new java.awt.Color(0, 102, 102));
        LPrice.setText("jLabel2");
        getContentPane().add(LPrice);
        LPrice.setBounds(370, 170, 230, 50);

        LDesc.setColumns(20);
        LDesc.setLineWrap(true);
        LDesc.setRows(5);
        jScrollPane1.setViewportView(LDesc);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(340, 260, 290, 96);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
            
        int pressok;
        dbconnect.insertData("insert into cart_details(customer_id,product_id,product_price,product_qty,status,payment_status)values('"+MyCart.user_cookie+"','"+this.item_id+"','"+price+"',1,'1','0')");
        JOptionPane.showMessageDialog(rootPane,"Item added to cart successfully...");
        
        
        this.setVisible(false);
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    
    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea LDesc;
    private javax.swing.JLabel LName;
    private javax.swing.JLabel LPrice;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel photo;
    // End of variables declaration//GEN-END:variables
}
