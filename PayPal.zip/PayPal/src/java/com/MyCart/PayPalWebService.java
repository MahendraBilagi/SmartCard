
package com.MyCart;

import javax.jws.WebService;
import javax.jws.WebMethod;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


@WebService(serviceName = "PayPalWebService")
public class PayPalWebService
{
    String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/bank";
        
        ResultSet rs;
        
        String USER = "root";
        String PASS = "";
        String email_id=null;
        //String name = null;
        String login_passwd=null;
        Connection conn = null;
        Statement stmt = null;
    
    PayPalWebService()
    {
        try 
            {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Connecting to database...");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
                
            } 
            catch (ClassNotFoundException ex) 
            {
                Logger.getLogger(PayPalWebService.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (SQLException ex) 
            {
                Logger.getLogger(PayPalWebService.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    @WebMethod(operationName = "insertData")
    public void insertData(String query)
        {
            try {
                    stmt = conn.createStatement();
                    stmt.executeUpdate(query);
                   
                } 
            catch (SQLException ex) 
                {
                    Logger.getLogger(PayPalWebService.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    
    @WebMethod(operationName = "getData")
    public int getData(String query)
        {
            int val = 0;
            try {
                    stmt = conn.createStatement();
                    rs = stmt.executeQuery(query);    
                   while(rs.next())
                   {
                       val = rs.getInt(4);
                   }
                } 
            catch (SQLException ex) 
                {
                    Logger.getLogger(PayPalWebService.class.getName()).log(Level.SEVERE, null, ex);
                }
            return val;
        }
    
}
