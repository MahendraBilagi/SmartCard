/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.MyCart;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Mons
 */
@WebService(serviceName = "VisaWebService")
public class VisaWebService 
{

    String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        String DB_URL = "jdbc:mysql://localhost/bank";
        
        ResultSet rs;
        
        String USER = "root";
        String PASS = "";
        String email_id=null;
        //String name = null;
        String login_passwd=null;
        Connection conn = null;
        Statement stmt = null;
    VisaWebService()
    {
        try 
            {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Connecting to database...");
                conn = DriverManager.getConnection(DB_URL,USER,PASS);
                
            } 
            catch (ClassNotFoundException ex) 
            {
                Logger.getLogger(VisaWebService.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (SQLException ex) 
            {
                Logger.getLogger(VisaWebService.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    
    
    
    @WebMethod(operationName = "insertData")
    public void insertData(String query)
        {
            try {
                    stmt = conn.createStatement();
                    stmt.executeUpdate(query);
                   
                } 
            catch (SQLException ex) 
                {
                    Logger.getLogger(VisaWebService.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    
    
    
    
    @WebMethod(operationName = "getData")
    public int getData(String query)
        {
            int val=0;
            try {
                    stmt = conn.createStatement();
                    rs = stmt.executeQuery(query);    
                   
                } 
            catch (SQLException ex) 
                {
                    Logger.getLogger(VisaWebService.class.getName()).log(Level.SEVERE, null, ex);
                }
            return val;
        }
    
        @Override
        protected void finalize() throws Throwable  
        {
            rs.close();
            stmt.close();
            conn.close();
            super.finalize();
        }
        
}
